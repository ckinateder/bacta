# Bacta

Bacta is a Python library for backtesting trading strategies.
![symbols](img/performance_analysis.png)

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install bacta.

```bash
pip install bacta
```

## Usage

### Making Plots

## Development

A docker image is provided for convenience. To build the image, run the following command:

```bash
docker build -t bacta . 
```

To run the image, run the following command:

```bash
docker run -it bacta --env-file .env
```

### Testing

To run the tests, run the following command:

```bash
python -m unittest discover test
```



## License

[MIT](https://choosealicense.com/licenses/mit/)